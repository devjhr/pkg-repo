#!/data/data/com.jahangir/files/usr/bin/sh

echo "$@"
